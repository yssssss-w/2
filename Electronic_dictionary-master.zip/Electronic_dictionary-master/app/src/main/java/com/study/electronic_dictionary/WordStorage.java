package com.study.electronic_dictionary;

public class WordStorage {
    public WordStorage() {
    }
    public static WordValue storeValue = null;
}
